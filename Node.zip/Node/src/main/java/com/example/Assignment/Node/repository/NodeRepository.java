package com.example.Assignment.Node.repository;

import com.example.Assignment.Node.entity.NodeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NodeRepository extends JpaRepository<NodeEntity, Long> {

}

