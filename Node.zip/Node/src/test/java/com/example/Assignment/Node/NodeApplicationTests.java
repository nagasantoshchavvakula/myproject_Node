package com.example.Assignment.Node;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
